".tr".all(function(elem){
	elem.parentNode.innerHTML=elem.html().tr;
});